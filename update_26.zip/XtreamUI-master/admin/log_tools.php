<?php
include "session.php"; include "functions.php";
if ((!$rPermissions["is_admin"]) OR (!hasPermissions("adv", "stream_tools"))) { exit; }

if (isset($_POST["submit_clear_log"]) && hasPermissions("adv", "stream_tools")) {
    if (isset($_POST["clear_log_auto"])) {
        $rAdminSettings["clear_log_auto"] = true;
        unset($_POST["clear_log_auto"]);
    } else {
        $rAdminSettings["clear_log_auto"] = false;
    }
    if (isset($_POST["clear_log_older_than_days"]) && preg_match("/^[1-9][0-9]*\$/", $_POST["clear_log_older_than_days"])) {
        $rAdminSettings["clear_log_older_than_days"] = $_POST["clear_log_older_than_days"];
        unset($_POST["clear_log_older_than_days"]);
    } else {
        $rAdminSettings["clear_log_older_than_days"] = $daysToClear;
        unset($_POST["clear_log_older_than_days"]);
    }
    if (isset($_POST["clear_log_tables"])) {
        if (!is_array($_POST["clear_log_tables"])) {
            $rAdminSettings["clear_log_tables"] = [$_POST["clear_log_tables"]];
        }
        $rAdminSettings["clear_log_tables"] = json_encode($_POST["clear_log_tables"]);
        unset($_POST["clear_log_tables"]);
    } else {
        $rAdminSettings["clear_log_tables"] = [];
    }
    $rAdminSettings["clear_log_check"] = time();
    writeAdminSettings();
    $_STATUS = 1;
    $db->query("INSERT INTO `panel_logs`(`log_message`, `date`) VALUES('" . ESC("Clear Logs Saved: " . date("d-m-Y H:m", $rAdminSettings["clear_log_check"]) . " and will be deleted in: " . date("d-m-Y H:m", $rAdminSettings["clear_log_check"] + $rAdminSettings["clear_log_older_than_days"] * 86400)) . "', " . intval(time()) . ");");
}

if ($rPermissions["is_admin"]) {
    $sql = "SELECT round(((data_length + index_length)/1024/1024),2)'user_activity' FROM information_schema.TABLES WHERE table_schema = 'xtream_iptvpro' AND table_name ='user_activity'; "; 
    $result = $db->query($sql);
    while ($row = $result->fetch_assoc()) {
    $user_activity = $row["user_activity"];
	}
	$sql = "SELECT round(((data_length + index_length)/1024/1024),2)'user_activity_now' FROM information_schema.TABLES WHERE table_schema = 'xtream_iptvpro' AND table_name ='user_activity_now'; "; 
    $result = $db->query($sql);
    while ($row = $result->fetch_assoc()) {
    $user_activity_now = $row["user_activity_now"];
    }	
	$sql = "SELECT round(((data_length + index_length)/1024/1024),2)'panel_logs' FROM information_schema.TABLES WHERE table_schema = 'xtream_iptvpro' AND table_name ='panel_logs'; "; 
    $result = $db->query($sql);
    while ($row = $result->fetch_assoc()) {
    $panel_logs = $row["panel_logs"];
    }
	$sql = "SELECT round(((data_length + index_length)/1024/1024),2)'stream_logs' FROM information_schema.TABLES WHERE table_schema = 'xtream_iptvpro' AND table_name ='stream_logs'; "; 
    $result = $db->query($sql);
    while ($row = $result->fetch_assoc()) {
    $stream_logs = $row["stream_logs"];
    }
	$sql = "SELECT round(((data_length + index_length)/1024/1024),2)'login_logs' FROM information_schema.TABLES WHERE table_schema = 'xtream_iptvpro' AND table_name ='login_logs'; "; 
    $result = $db->query($sql);
    while ($row = $result->fetch_assoc()) {
    $login_logs = $row["login_logs"];
    }
	$sql = "SELECT round(((data_length + index_length)/1024/1024),2)'client_logs' FROM information_schema.TABLES WHERE table_schema = 'xtream_iptvpro' AND table_name ='client_logs'; "; 
    $result = $db->query($sql);
    while ($row = $result->fetch_assoc()) {
    $client_logs = $row["client_logs"];
    }
	$sql = "SELECT round(((data_length + index_length)/1024/1024),2)'login_flood' FROM information_schema.TABLES WHERE table_schema = 'xtream_iptvpro' AND table_name ='login_flood'; "; 
    $result = $db->query($sql);
    while ($row = $result->fetch_assoc()) {
    $login_flood = $row["login_flood"];
    }
	$sql = "SELECT round(((data_length + index_length)/1024/1024),2)'mag_events' FROM information_schema.TABLES WHERE table_schema = 'xtream_iptvpro' AND table_name ='mag_events'; "; 
    $result = $db->query($sql);
    while ($row = $result->fetch_assoc()) {
    $mag_events = $row["mag_events"];
    }
	$sql = "SELECT round(((data_length + index_length)/1024/1024),2)'mag_claims' FROM information_schema.TABLES WHERE table_schema = 'xtream_iptvpro' AND table_name ='mag_claims'; "; 
    $result = $db->query($sql);
    while ($row = $result->fetch_assoc()) {
    $mag_claims = $row["mag_claims"];
    }
	$sql = "SELECT round(((data_length + index_length)/1024/1024),2)'mag_logs' FROM information_schema.TABLES WHERE table_schema = 'xtream_iptvpro' AND table_name ='mag_logs'; "; 
    $result = $db->query($sql);
    while ($row = $result->fetch_assoc()) {
    $mag_logs = $row["mag_logs"];
    }
	$sql = "SELECT round(((data_length + index_length)/1024/1024),2)'tmdb_async' FROM information_schema.TABLES WHERE table_schema = 'xtream_iptvpro' AND table_name ='tmdb_async'; "; 
    $result = $db->query($sql);
    while ($row = $result->fetch_assoc()) {
    $tmdb_async = $row["tmdb_async"];
    }
	$sql = "SELECT round(((data_length + index_length)/1024/1024),2)'watch_output' FROM information_schema.TABLES WHERE table_schema = 'xtream_iptvpro' AND table_name ='watch_output'; "; 
    $result = $db->query($sql);
    while ($row = $result->fetch_assoc()) {
    $watch_output = $row["watch_output"];
    }
}

if (isset($_GET["flush"])) {
    flushActivity();
	$_STATUS = 1;
}

if (isset($_GET["flushnow"])) {
    flushActivitynow();
	$_STATUS = 1;
}

if (isset($_GET["flushpanel"])) {
    flushPanelogs();
	$_STATUS = 1;
}

if (isset($_GET["flushstlogs"])) {
    flushStlogs();
	$_STATUS = 1;
}

if (isset($_GET["flushevents"])) {
    flushEvents();
	$_STATUS = 1;
}

if (isset($_GET["flushclientlogs"])) {
    flushClientlogs();
	$_STATUS = 1;
}

if (isset($_GET["flushflood"])) {
    flushLogins();
	$_STATUS = 1;
}

if (isset($_GET["flushloginlogs"])) {
    flushLoginlogs();
	$_STATUS = 1;
}

if (isset($_GET["flushmagclaims"])) {
    flushMagclaims();
	$_STATUS = 1;
}

if (isset($_GET["flushmaglogs"])) {
    flushMaglogs();
	$_STATUS = 1;
}

if (isset($_GET["lockisp"])) {
    lockIsp();
	$_STATUS = 1;
}

if (isset($_GET["unlockisp"])) {
    unlockIsp();
	$_STATUS = 1;
}

if (isset($_GET["lockstb"])) {
    lockStb();
	$_STATUS = 1;
}

if (isset($_GET["unlockstb"])) {
    unlockStb();
	$_STATUS = 1;
}

if (isset($_GET["clearisp"])) {
    clearIsp();
	$_STATUS = 1;
}

/*if (isset($_GET["flushduplicatemovies"])) {
    flushDuplicateMovies();
	$_STATUS = 1;
}*/

if (isset($_GET["flushwatchfolder"])) {
    flushWatchFolder();
	$_STATUS = 1;
}

if (isset($_GET["flushtmdbasync"])) {
    flushTmdbAsync();
	$_STATUS = 1;
}

if ($rSettings["sidebar"]) {
    include "header_sidebar.php";
} else {
    include "header.php";
}
        if ($rSettings["sidebar"]) { ?>
        <div class="content-page"><div class="content boxed-layout-ext"><div class="container-fluid">
        <?php } else { ?>
        <div class="wrapper boxed-layout-ext"><div class="container-fluid">
        <?php } ?>
                <!-- start page title -->
                <div class="row">
                    <div class="col-12">
                        <div class="page-title-box">
                            <h4 class="page-title"> <?=$_["quick_tools"]?> </h4>
                        </div>
                    </div>
                </div>     
                <!-- end page title --> 
                <div class="row">
                    <div class="col-xl-12">
                        <?php if ((isset($_STATUS)) && ($_STATUS == 1)) { if (!$rSettings["sucessedit"]) { ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                             <?=$_["operation_performed_successfully"]?> 
                        </div>
						<?php } else { ?>
                    <script type="text/javascript">
  					swal("", '<?=$_["operation_performed_successfully"]?>', "success");
  					</script>
                        <?php } } ?>
                        <div class="card">
                            <div class="card-body">
								<div id="basicwizard">
									<ul class="nav nav-pills bg-light nav-justified form-wizard-header mb-4">
										<li class="nav-item">
											<a href="#clearlogs" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2"> 
												<i class="mdi mdi-cube mr-1"></i>
												<span class="d-none d-sm-inline"> <?=$_["quick_tools"]?> </span>
											</a>
										</li>
									</ul>
									<div class="tab-pane" id="clearlogs"></p>
									    <form action="./log_tools.php" method="POST" id="clear_logs_form">
										<div class="col-12">
										    <div class="form-group row mb-4">
											    <label class="col-md-4 col-form-label" for="clear_log_auto"> <?=$_["auto_clear_logs"]?> <i data-toggle="tooltip" data-placement="top" title="" data-original-title="<?=$_["here_you_can_enable_or_disable"]?>" class="mdi mdi-information"></i></label>
											    <div class="col-md-2">
													<input name="clear_log_auto" id="clear_log_auto" type="checkbox"<?php if ($rAdminSettings["clear_log_auto"] == 1) { echo "checked "; } ?>data-plugin="switchery" class="js-switch" data-color="#039cfd"/>
												</div>
												<label class="col-md-4 col-form-label" for="clear_log_older_than_days"> <?=$_["clear_logs_in"]?> <i data-toggle="tooltip" data-placement="top" title="" data-original-title="<?=$_["minimum_value_is"]?>" class="mdi mdi-information"></i></label>
                                                <div class="col-md-1">
                                                    <input type="text" class="form-control" id="clear_log_older_than_days" name="clear_log_older_than_days" min="1" value="<?=htmlspecialchars($rAdminSettings["clear_log_older_than_days"] ? $rAdminSettings["clear_log_older_than_days"] : $daysToClear)?>" required>
                                                </div>
												<label class="col-md-1 col-form-label" for="clear_log_older_than_days"> <?=$_["days"]?> <i data-toggle="tooltip" data-placement="top" title="" data-original-title=""></i></label>
											</div>
											<div class="form-group row mb-4">
												<label class="col-md-4 col-form-label" for="clear_log_tables"> <?=$_["logs_to_clear"]?> <i data-toggle="tooltip" data-placement="top" title="" data-original-title="<?=$_["here_you_can_choose_the_logs"]?>" class="mdi mdi-information"></i></label>
												<div class="col-md-8">
												    <select name="clear_log_tables[]" id="clear_log_tables" class="form-control select2-multiple" data-toggle="select2" multiple="multiple" data-placeholder="<?=$_["choose"]?>...">
													<?php
                                                    foreach (Array("Users Activity" => "flushActivity", "Users Activity Now" => "flushActivitynow", "Panel Logs" => "flushPanelogs", "Login Logs" => "flushLoginlogs", "Login Flood" => "flushLogins", "Mag Claims" => "flushMagclaims", "Stream Logs" => "flushStlogs", "Client Logs" => "flushClientlogs", "Mag Events" => "flushEvents", "Mag Logs" => "flushMaglogs") as $rKey => $rFtable) { ?>
													<option <?php if (in_array($rFtable, json_decode($rAdminSettings["clear_log_tables"], True))) { echo "selected "; } ?>value="<?=$rFtable?>"><?=$rKey?></option>
													<?php } ?>
                                                    </select>
												</div>
											</div>
										</div>
										<ul class="list-inline wizard mb-0" style="margin-top:30px;">
										    <li class="list-inline-item float-left"><input name="submit_clear_log" type="submit" class="btn btn-primary" value="<?=$_["save_changes"]?>">
										    </li>
										</ul><br /><br /><hr />
										</form>
                                            <div class="col-12">
											    <div class="form-group row mb-4">
												    <label class="col-md-3 col-form-label"><a href="./tables_mb.php"><?=$_["show_all_tables"]?></a></label>
											    </div>
                                                <div class="form-group row mb-4">
                                                    <label class="col-md-3 col-form-label"><span class="btn btn-pink btn-xs btn-fixed waves-effect waves-light"><?php echo $user_activity;?> MB</span> <?=$_["clear_users_activity"]?> </label>
                                                    <div class="col-md-2">
														<a href="log_tools.php?flush">
                                                        <button onclick="return confirm('<?=$_["do_you_want_to_clear_activity"]?>')" type="button" class="btn btn-success" style="width:100%;">
                                                        <?=$_["run_action"]?>
                                                        </button>
                                                        </a>
                                                    </div>
                                                    <div class="col-md-2"></div>
                                                    <label class="col-md-3 col-form-label"><span class="btn btn-pink btn-xs btn-fixed waves-effect waves-light"><?php echo $user_activity_now;?> MB</span> <?=$_["clear_users_activity_now"]?></label>
                                                    <div class="col-md-2">
														<a href="log_tools.php?flushnow">
                                                        <button onclick="return confirm('<?=$_["do_you_want_to_clear_users_activity"]?>')" type="button" class="btn btn-success" style="width:100%;">
                                                        <?=$_["run_action"]?>
                                                        </button>
                                                        </a>
                                                    </div>
                                                </div>
												<br>
                                                <div class="form-group row mb-4">
                                                    <label class="col-md-3 col-form-label"><span class="btn btn-pink btn-xs btn-fixed waves-effect waves-light"><?php echo $panel_logs;?> MB</span> <?=$_["clear_panel_logs"]?></label>
                                                    <div class="col-md-2">
														<a href="log_tools.php?flushpanel">
                                                        <button onclick="return confirm('<?=$_["do_you_want_to_clear_panel_logs"]?>')" type="button" class="btn btn-success" style="width:100%;">
                                                        <?=$_["run_action"]?>
                                                        </button>
                                                        </a>
                                                    </div>
                                                    <div class="col-md-2"></div>
                                                    <label class="col-md-3 col-form-label"><span class="btn btn-pink btn-xs btn-fixed waves-effect waves-light"><?php echo $stream_logs;?> MB</span> <?=$_["clear_stream_logs"]?></label>
                                                    <div class="col-md-2">
														<a href="log_tools.php?flushstlogs">
                                                        <button onclick="return confirm('<?=$_["do_you_want_to_clear_stream_logs"]?>')" type="button" class="btn btn-success" style="width:100%;">
                                                        <?=$_["run_action"]?>
                                                        </button>
                                                        </a>
                                                    </div>
                                                </div>
												<br>
                                                <div class="form-group row mb-4">
                                                    <label class="col-md-3 col-form-label"><span class="btn btn-pink btn-xs btn-fixed waves-effect waves-light"><?php echo $login_logs;?> MB</span> <?=$_["clear_login_logs"]?></label>
                                                    <div class="col-md-2">
														<a href="log_tools.php?flushloginlogs">
                                                        <button onclick="return confirm('<?=$_["do_you_want_to_clear_logins_logs"]?>')" type="button" class="btn btn-success" style="width:100%;">
                                                        <?=$_["run_action"]?>
                                                        </button>
                                                        </a>
                                                    </div>
                                                    <div class="col-md-2"></div>
                                                    <label class="col-md-3 col-form-label"><span class="btn btn-pink btn-xs btn-fixed waves-effect waves-light"><?php echo $client_logs;?> MB</span> <?=$_["clear_client_logs"]?></label>
                                                    <div class="col-md-2">
														<a href="log_tools.php?flushclientlogs">
                                                        <button onclick="return confirm('<?=$_["do_you_want_to_clear_clients_logs"]?>')" type="button" class="btn btn-success" style="width:100%;">
                                                        <?=$_["run_action"]?>
                                                        </button>
                                                        </a>
                                                    </div>
                                                </div>
												<br>
												<div class="form-group row mb-4">
                                                    <label class="col-md-3 col-form-label"><span class="btn btn-pink btn-xs btn-fixed waves-effect waves-light"><?php echo $login_flood;?> MB</span> <?=$_["clear_login_flood"]?></label>
                                                    <div class="col-md-2">
														<a href="log_tools.php?flushflood">
                                                        <button onclick="return confirm('<?=$_["do_you_want_to_clear_login_flood"]?>')" type="button" class="btn btn-success" style="width:100%;">
                                                        <?=$_["run_action"]?>
                                                        </button>
                                                        </a>
                                                    </div>
                                                    <div class="col-md-2"></div>
                                                    <label class="col-md-3 col-form-label"><span class="btn btn-pink btn-xs btn-fixed waves-effect waves-light"><?php echo $mag_events;?> MB</span> <?=$_["clear_mag_events"]?></label>
                                                    <div class="col-md-2">
														<a href="log_tools.php?flushevents">
                                                        <button onclick="return confirm('<?=$_["do_you_want_to_clear_mag_events"]?>')" type="button" class="btn btn-success" style="width:100%;">
                                                        <?=$_["run_action"]?>
                                                        </button>
                                                        </a>
                                                    </div>
                                                </div>
												<br>
												<div class="form-group row mb-4">
                                                    <label class="col-md-3 col-form-label"><span class="btn btn-pink btn-xs btn-fixed waves-effect waves-light"><?php echo $mag_claims;?> MB</span> <?=$_["clear_mag_claims"]?></label>
                                                    <div class="col-md-2">
														<a href="log_tools.php?flushmagclaims">
                                                        <button onclick="return confirm('<?=$_["do_you_want_to_clear_mag_claims"]?>')" type="button" class="btn btn-success" style="width:100%;">
                                                        <?=$_["run_action"]?>
                                                        </button>
                                                        </a>
                                                    </div>
                                                    <div class="col-md-2"></div>
                                                    <label class="col-md-3 col-form-label"><span class="btn btn-pink btn-xs btn-fixed waves-effect waves-light"><?php echo $mag_logs;?> MB</span> <?=$_["clear_mag_logs"]?></label>
                                                    <div class="col-md-2">
														<a href="log_tools.php?flushmaglogs">
                                                        <button onclick="return confirm('<?=$_["do_you_want_to_clear_mag_logs"]?>')" type="button" class="btn btn-success" style="width:100%;">
                                                        <?=$_["run_action"]?>
                                                        </button>
                                                        </a>
                                                    </div>
                                                </div>
												<br>
												<div class="form-group row mb-4">
												    <label class="col-md-3 col-form-label"><span class="btn btn-pink btn-xs btn-fixed waves-effect waves-light"><?php echo $watch_output;?> MB</span> <?=$_["clear_folder_watch"]?></label>
                                                    <div class="col-md-2">
														<a href="log_tools.php?flushwatchfolder">
                                                        <button onclick="return confirm('<?=$_["do_you_want_to_clear_folder_watch"]?>')" type="button" class="btn btn-success" style="width:100%;">
                                                        <?=$_["run_action"]?>
                                                        </button>
                                                        </a>
                                                    </div>
													<div class="col-md-2"></div>
                                                    <label class="col-md-3 col-form-label"><span class="btn btn-pink btn-xs btn-fixed waves-effect waves-light"><?php echo $tmdb_async;?> MB</span> <?=$_["clear_re_process_tmdb"]?></label>
                                                    <div class="col-md-2">
														<a href="log_tools.php?flushtmdbasync">
                                                        <button onclick="return confirm('<?=$_["do_you_want_to_clear_re_process"]?>')" type="button" class="btn btn-success" style="width:100%;">
                                                        <?=$_["run_action"]?>
                                                        </button>
                                                        </a>
                                                    </div>
                                                </div>
												<br>
												<div class="form-group row mb-4">
                                                    <label class="col-md-3 col-form-label"><?=$_["lock_isp"]?></label>
                                                    <div class="col-md-2">
														<a href="log_tools.php?lockisp">
                                                        <button onclick="return confirm('<?=$_["do_you_want_to_clear_lock_isp"]?>')" type="button" class="btn btn-success" style="width:100%;">
                                                        <?=$_["run_action"]?>
                                                        </button>
                                                        </a>
                                                    </div>
                                                    <div class="col-md-2"></div>
                                                    <label class="col-md-3 col-form-label"><?=$_["unlock_isp"]?></label>
                                                    <div class="col-md-2">
														<a href="log_tools.php?unlockisp">
                                                        <button onclick="return confirm('<?=$_["do_you_want_to_clear_unlock_isp"]?>')" type="button" class="btn btn-success" style="width:100%;">
                                                        <?=$_["run_action"]?>
                                                        </button>
                                                        </a>
                                                    </div>
                                                </div>
												<br>
												<div class="form-group row mb-4">
                                                    <label class="col-md-3 col-form-label"><?=$_["device_lock"]?></label>
                                                    <div class="col-md-2">
														<a href="log_tools.php?lockstb">
                                                        <button onclick="return confirm('<?=$_["do_you_want_to_clear_device_lock"]?>')" type="button" class="btn btn-success" style="width:100%;">
                                                        <?=$_["run_action"]?>
                                                        </button>
                                                        </a>
                                                    </div>
                                                    <div class="col-md-2"></div>
                                                    <label class="col-md-3 col-form-label"><?=$_["device_unlock"]?></label>
                                                    <div class="col-md-2">
														<a href="log_tools.php?unlockstb">
                                                        <button onclick="return confirm('<?=$_["do_you_want_to_clear_device_unlock"]?>')" type="button" class="btn btn-success" style="width:100%;">
                                                        <?=$_["run_action"]?>
                                                        </button>
                                                        </a>
                                                    </div>
                                                </div>
												<br>
												<div class="form-group row mb-4">
                                                    <!--<label class="col-md-3 col-form-label"><?=$_["clear_duplicate_movies"]?></label>
                                                    <div class="col-md-2">
														<a href="log_tools.php?flushduplicatemovies">
                                                        <button onclick="return confirm('<?=$_["do_you_want_to_clear_duplicate_movies"]?>')" type="button" class="btn btn-success" style="width:100%;">
                                                     <?=$_["run_action"]?>
                                                        </button>
                                                        </a>
                                                    </div>
													<div class="col-md-2"></div>-->
													<label class="col-md-3 col-form-label"><?=$_["clear_isp"]?></label>
                                                    <div class="col-md-2">
														<a href="log_tools.php?clearisp">
                                                        <button onclick="return confirm('<?=$_["do_you_want_to_clear_isp"]?>')" type="button" class="btn btn-success" style="width:100%;">
                                                        <?=$_["run_action"]?>
                                                        </button>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div> 
                                        </div> <!-- tab-content -->
								</div> <!-- end #basicwizard-->
                            </div> <!-- end card-body -->
                        </div> <!-- end card-->
                    </div> <!-- end col -->
                </div>
            </div> <!-- end container -->
        </div>
        <!-- end wrapper -->
        <?php if ($rSettings["sidebar"]) { echo "</div>"; } ?>
        <!-- Footer Start -->
        <footer class="footer">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12 copyright text-center"><?=getFooter()?></div>
                </div>
            </div>
        </footer>
        <!-- end Footer -->

        <script src="assets/js/vendor.min.js"></script>
        <script src="assets/libs/jquery-toast/jquery.toast.min.js"></script>
        <script src="assets/libs/jquery-nice-select/jquery.nice-select.min.js"></script>
        <script src="assets/libs/switchery/switchery.min.js"></script>
        <script src="assets/libs/select2/select2.min.js"></script>
        <script src="assets/libs/bootstrap-touchspin/jquery.bootstrap-touchspin.min.js"></script>
        <script src="assets/libs/bootstrap-maxlength/bootstrap-maxlength.min.js"></script>
        <script src="assets/libs/clockpicker/bootstrap-clockpicker.min.js"></script>
        <script src="assets/libs/moment/moment.min.js"></script>
        <script src="assets/libs/daterangepicker/daterangepicker.js"></script>
        <script src="assets/libs/datatables/jquery.dataTables.min.js"></script>
        <script src="assets/libs/datatables/dataTables.bootstrap4.js"></script>
        <script src="assets/libs/datatables/dataTables.responsive.min.js"></script>
        <script src="assets/libs/datatables/responsive.bootstrap4.min.js"></script>
        <script src="assets/libs/datatables/dataTables.buttons.min.js"></script>
        <script src="assets/libs/datatables/buttons.bootstrap4.min.js"></script>
        <script src="assets/libs/datatables/buttons.html5.min.js"></script>
        <script src="assets/libs/datatables/buttons.flash.min.js"></script>
        <script src="assets/libs/datatables/buttons.print.min.js"></script>
        <script src="assets/libs/datatables/dataTables.keyTable.min.js"></script>
        <script src="assets/libs/datatables/dataTables.select.min.js"></script>
        <script src="assets/libs/parsleyjs/parsley.min.js"></script>
        <script src="assets/libs/twitter-bootstrap-wizard/jquery.bootstrap.wizard.min.js"></script>
        <script src="assets/js/pages/form-wizard.init.js"></script>
        <script src="assets/js/app.min.js"></script>

		<script>
		$(window).on('load', function() {
		var elem = document.querySelector('#clear_log_auto');
		var init = new Switchery(elem);
		$('#clear_log_tables').select2();
		}
		);
		</script>
    </body>
</html>